const redis = require('redis');
const client = redis.createClient();
const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const bluebird = require('bluebird');
const redisConnection = require("./redis-connection");
const nrpSender = require("./nrp-sender-shim");
bluebird.promisifyAll(redis.RedisClient.prototype);
bluebird.promisifyAll(redis.Multi.prototype);
app.use(bodyParser.json());

app.get("/api/people/:id", async function (req, res)
{
    try
    {
        let Response = await nrpSender.sendMessage({
            redis: redisConnection,
            eventName: 'getPersonByID',
            data: {
                id: req.params.id
            },
            expectsResponse: true
        });

        res.json(Response);
    }
    catch (err)
    {
           res.status(504).json(err.message);
    }
});

app.post("/api/people", async function (req, res)
{
    try
    {
        let Response = await nrpSender.sendMessage({
            redis: redisConnection,
            eventName: 'createPerson',
            data: {
                person: req.body
            },
            expectsResponse: true
        });

        res.json(Response);
    }
    catch (err)
    {
        res.status(504).json(err.message);
    }
});

app.delete("/api/people/:id", async function (req, res)
{
    try
    {
        let Response = await nrpSender.sendMessage({
            redis: redisConnection,
            eventName: 'deletePersonByID',
            data: {
                id: req.params.id
            },
            expectsResponse: true
        });

        res.json(Response);
    }
    catch (err)
    {
        res.status(504).json(err.message);
    }
});

app.put("/api/people/:id", async function (req, res)
{
    try
    {
        let Response = await nrpSender.sendMessage({
            redis: redisConnection,
            eventName: 'updatePersonByID',
            data: {
                id: req.params.id,
                person: req.body
            },
            expectsResponse: true
        });

        res.json(Response);
    }
    catch (err)
    {
        res.status(504).json(err.message);
    }
});

app.use("*", function (req, res)
{
    res.status(404).json("Route Not Found");
});

app.listen(3000, function() {
    console.log("We've now got a server!");
    console.log("Your routes will be running on http://localhost:3000!!!!m");
});