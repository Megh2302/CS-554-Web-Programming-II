const axios = require("axios");
const request = require('request-promise');
const redisConnection = require('./redis-connection');

const url = 'https://gist.githubusercontent.com/philbarresi/5cf15393d245b38a2d86ce8207d5076c/raw/d529fb474c1af347702ca4d7b992256237fa2819/lab5.json';

(async function() {
    let data = await axios.get(url);
    data = data.data;

    console.log("HII.....!!!!!");

    redisConnection.on('getPersonByID:request:*', function (message, channel) {
        let requestId = message.requestId;
        let eventName = message.eventName;
        let id = parseInt(message.data.id, 10);
        let successEvent = `${eventName}:success:${requestId}`;
        let failedEvent = `${eventName}:failed:${requestId}`;

        if (isNaN(id) || id <= 0)
        {
            redisConnection.emit(failedEvent,
                {
                requestId: requestId,
                data: {
                    message: 'ID is invalid',
                    errorCode: 400
                },
                eventName: eventName
            });
        }
        let person = null;
        for (let i = 0; i < data.length; i++) {
            if (data[i]['id'] == id) {
                person = data[i];
                break;
            }
        }
        if (person !== null) {
            redisConnection.emit(successEvent, {
                requestId: requestId,
                data: person,
                eventName: eventName
            });
        }
        else
        {
            redisConnection.emit(failedEvent, {
                requestId: requestId,
                data: {
                    message: 'Person is not found',
                    errorCode: 404
                },
                eventName: eventName
            });
        }
    });

    redisConnection.on('createPerson:request:*', function (message, channel) {
        let requestId = message.requestId;
        let eventName = message.eventName;

        let successEvent = `${eventName}:success:${requestId}`;
        let failedEvent = `${eventName}:failed:${requestId}`;

        let info = message.data.person;
        let errMsg = '';
        if (info.id === null || info.id === undefined)
        {
            errMsg = 'ID is required';
        }
        else if (info.first_name === null || info.first_name === undefined)
        {
            errMsg = 'First Name is required';
        }
        else if (info.last_name === null || info.last_name === undefined)
        {
            errMsg = 'Last Name is required';
        }
        else if (info.email === null || info.email === undefined)
        {
            errMsg = 'Email_ID is required';
        }
        else if (info.gender === null || info.gender === undefined)
        {
            errMsg = 'Gender is required';
        }
        else if (info.ip_address === null || info.ip_address === undefined)
        {
            errMsg = 'IP Address is required';
        }
        else if (isNaN(info.id) || info.id <= 0 || typeof(info.id) !== 'number')
        {
            errMsg = 'ID is invalid';
        }
        else if (typeof(info.first_name) !== 'string')
        {
            errMsg = 'First Name is invalid';
        }
        else if (typeof(info.last_name) !== 'string')
        {
            errMsg = 'Last Name is invalid';
        }
        else if (typeof(info.email) !== 'string')
        {
            errMsg = 'Email_ID is invalid';
        }
        else if (typeof(info.gender) !== 'string')
        {
            errMsg = 'Gender is invalid';
        }
        else if (typeof(info.ip_address) !== 'string')
        {
            errMsg = 'IP Address is invalid';
        }

        for (let i = 0; i < data.length; i++) {
            if (data[i]['id'] == info.id) {
                errMsg = 'ID is invalid';
            }
        }

        if (errMsg == '') {
            data.push(info);
            redisConnection.emit(successEvent, {
                requestId: requestId,
                data: info,
                eventName: eventName
            });
        } else {
            redisConnection.emit(failedEvent, {
                requestId: requestId,
                data: {
                    message: errMsg,
                    errorCode: 400
                },
                eventName: eventName
            });
        }
    });


    redisConnection.on('deletePersonByID:request:*', function (message, channel) {
        let requestId = message.requestId;
        let eventName = message.eventName;

        let id = parseInt(message.data.id, 10);

        let successEvent = `${eventName}:success:${requestId}`;
        let failedEvent = `${eventName}:failed:${requestId}`;

        if (isNaN(id) || id <= 0)
        {
            redisConnection.emit(failedEvent,
                {
                    requestId: requestId,
                    data: {
                        message: 'ID is invalid',
                        errorCode: 400
                    },
                    eventName: eventName
                });
        }

        let person = false;
        for (let i = 0; i < data.length; i++) {
            if (data[i]['id'] == id) {
                data.splice(i, 1);
                person = true;
                break;
            }
        }

        if (person) {
            redisConnection.emit(successEvent, {
                requestId: requestId,
                data: {
                    success: 'Person deleted'
                },
                eventName: eventName
            });
        } else {
            redisConnection.emit(failedEvent, {
                requestId: requestId,
                data: {
                    message: 'Person is not found!!',
                    errorCode: 404
                },
                eventName: eventName
            });
        }
    });

    redisConnection.on('updatePersonByID:request:*', function (message, channel) {
        let requestId = message.requestId;
        let eventName = message.eventName;

        let successEvent = `${eventName}:success:${requestId}`;
        let failedEvent = `${eventName}:failed:${requestId}`;

        let id = parseInt(message.data.id, 10);
        let info = message.data.person;
        let errMsg = '';

        //error check given fields, use id from route not body
        if (id === null || id === undefined)
        {
            errMsg = 'ID is required';
        }
        else if (info.first_name === null || info.first_name === undefined)
        {
            errMsg = 'First Name is required';
        }
        else if (info.last_name === null || info.last_name === undefined)
        {
            errMsg = 'Last Name is required';
        }
        else if (info.email === null || info.email === undefined)
        {
            errMsg = 'Email_ID is required';
        }
        else if (info.gender === null || info.gender === undefined)
        {
            errMsg = 'Gender is required';
        }
        else if (info.ip_address === null || info.ip_address === undefined)
        {
            errMsg = 'IP Address is required';
        }
        else if (isNaN(id) || id <= 0 || typeof(id) !== 'number')
        {
            errMsg = 'ID is invalid';
        }
        else if (typeof(info.first_name) !== 'string')
        {
            errMsg = 'First Name is invalid';
        }
        else if (typeof(info.last_name) !== 'string')
        {
            errMsg = 'Last Name is invalid';
        }
        else if (typeof(info.email) !== 'string')
        {
            errMsg = 'Email_ID is invalid';
        }
        else if (typeof(info.gender) !== 'string')
        {
            errMsg = 'Gender is invalid';
        }
        else if (typeof(info.ip_address) !== 'string')
        {
            errMsg = 'IP Address is invalid';
        }

        let person = false;
        for (let i = 0; i < data.length; i++) {
            if (data[i]['id'] == id) {
                data.splice(i, 1, info);
                person = true;
                break;
            }
        }

        if (errMsg == '' && person)
        {
            redisConnection.emit(successEvent, {
                requestId: requestId,
                data: info,
                eventName: eventName
            });
        }
        else
            {
            if (!person)
            {
                redisConnection.emit(failedEvent, {
                    requestId: requestId,
                    data: {
                        message: 'Person is not found',
                        errorCode: 404
                    },
                    eventName: eventName
                });
            }
            else
                {
                redisConnection.emit(failedEvent, {
                    requestId: requestId,
                    data: {
                        message: errMsg,
                        errorCode: 400
                    },
                    eventName: eventName
                });
            }
        }
    });
}());


